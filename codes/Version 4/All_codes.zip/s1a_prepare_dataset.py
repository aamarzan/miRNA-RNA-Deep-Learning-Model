# s1a_prepare_dataset.py
# Final, unbiased, RAM-safe, multi-part Parquet, with chunked streaming and optional parallel row building

import os
import pandas as pd
from Bio import SeqIO
import numpy as np
import re
import json
from itertools import product, islice
from multiprocessing import Pool, cpu_count
import time
from tqdm import tqdm
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.dataset as ds
import math
import random

# Reproducibility
random.seed(42)
np.random.seed(42)

# --- Import the processors library ---
# Must be available in PYTHONPATH or same directory as this script.
from molecule_processors import PROCESSOR_MAP

# ==============================
# CONFIGURATION LOADER
# ==============================
def load_config(config_path=None):
    if config_path is None:
        # Looks for config.json in the same directory as the script.
        script_dir = os.path.dirname(os.path.realpath(__file__))
        config_path = os.path.join(script_dir, 'config.json')
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"FATAL: Configuration file not found at '{config_path}'.")
        exit()

# ==============================
# FILE AND DATA LOADERS
# ==============================
def _get_files_in_folder(folder_path, extensions):
    if not os.path.exists(folder_path):
        return []
    return [
        os.path.join(folder_path, f)
        for f in os.listdir(folder_path)
        if any(f.lower().endswith(ext) for ext in extensions)
    ]

def load_data_from_fasta(folder_path):
    data_dict = {}
    file_paths = _get_files_in_folder(folder_path, ['.fasta', '.fa', '.fna', '.txt'])
    for filepath in file_paths:
        try:
            for record in SeqIO.parse(filepath, "fasta"):
                data_dict[record.id] = str(record.seq)
        except Exception:
            # Silently skip malformed FASTA files, as in your original
            pass
    return data_dict

def load_scores(folder_path, id_col, score_col, file_type_name):
    data_dict = {}
    print(f"  Scanning {file_type_name} files in '{folder_path}'...")
    for filepath in _get_files_in_folder(folder_path, ['.txt', '.tsv', '.csv']):
        try:
            sep = '\t' if filepath.lower().endswith(('.txt', '.tsv')) else ','
            df = pd.read_csv(
                filepath, sep=sep, comment='#',
                usecols=[id_col, score_col], dtype={id_col: str},
                low_memory=False
            )
            df.dropna(inplace=True)
            for _, row in df.iterrows():
                data_dict[str(row[id_col])] = float(row[score_col])
        except Exception as e:
            print(f"    - Error loading score file {filepath}: {e}")
    return data_dict

# ==============================
# DIAGNOSTICS
# ==============================
def run_id_matching_diagnostics(mirna_data, affinity_data):
    """
    Cleans complex IDs and provides a detailed report on the match rate between
    miRNA sequences and affinity family/score priors.
    """
    print("\n--- Running ID Matching Diagnostics ---")
    if not mirna_data or not affinity_data:
        print("  - Skipping diagnostics: miRNA or affinity data not loaded.")
        return

    def normalize_id(key):
        return key.strip().split()[0]

    mirna_ids = {normalize_id(k) for k in mirna_data.keys()}
    affinity_ids = {normalize_id(k) for k in affinity_data.keys()}

    matched_ids = mirna_ids.intersection(affinity_ids)
    affinity_only_ids = affinity_ids - mirna_ids
    mirna_only_ids = mirna_ids - affinity_ids

    print(f"Total Unique miRNA IDs from FASTA (normalized): {len(mirna_ids)}")
    print(f"Total Unique IDs from Affinity File (normalized): {len(affinity_ids)}")
    print(f"  - Number of Matched IDs: {len(matched_ids)}")

    if affinity_only_ids:
        print(f"\nWARNING: {len(affinity_only_ids)} IDs are in the Affinity File but NOT in the miRNA FASTA file.")
        print(f"  (These scores will be ignored. Example IDs: {list(affinity_only_ids)[:5]})")

    if mirna_only_ids:
        print(f"\nNOTE: {len(mirna_only_ids)} miRNAs have sequences but NO affinity score.")
        print(f"  (They won’t get random labels anymore; pairwise labels will be computed.)")

    print("---------------------------------------")

# ==============================
# PROXY-LABEL HELPERS
# ==============================
def seed_match_score(mirna_u, target_u, seed_len=7):
    m = (mirna_u or "").replace('T','U').upper()
    t = (target_u or "").replace('T','U').upper()
    if len(m) < seed_len + 1 or len(t) < seed_len:
        return 0.0, 0
    seed = m[1:1+seed_len]
    comp = str.maketrans('AUGC', 'UACG')
    seed_comp = seed.translate(comp)
    best = 0
    best_pos = 0
    for i in range(0, len(t) - seed_len + 1):
        window = t[i:i+seed_len]
        matches = sum(1 for a, b in zip(seed_comp, window) if a == b)
        if matches > best:
            best = matches
            best_pos = i
    return best / seed_len, best_pos

def gc_strength_score(mirna_u, target_u, start_pos):
    m = (mirna_u or "").replace('T','U').upper()
    t = (target_u or "").replace('T','U').upper()
    if len(m) < 8 or start_pos + 7 > len(t):
        return 0.0
    seed = m[1:8]
    comp = str.maketrans('AUGC', 'UACG')
    seed_comp = seed.translate(comp)
    window = t[start_pos:start_pos+7]
    score = 0.0
    for a, b in zip(seed_comp, window):
        if a == b:
            score += 1.0 if a in ('G', 'C') else 0.6
    return score / 7.0

def accessibility_score(dot_bracket_json, start_pos, length=7):
    try:
        vec = json.loads(dot_bracket_json or "[]")
    except Exception:
        vec = []
    if not vec or start_pos + length > len(vec):
        return 0.0
    # encoded: . -> 0 (unpaired), ( -> 1, ) -> -1
    unpaired = sum(1 for v in vec[start_pos:start_pos+length] if v == 0)
    return unpaired / float(length)

def normalize_feature_01(x, lo=0.0, hi=1.0):
    if hi <= lo:
        return 0.0
    v = (x - lo) / (hi - lo)
    return max(0.0, min(1.0, v))

normalize_01 = normalize_feature_01
    
# ==============================
# COMPETITOR PROPENSITY (VECTORIZED)
# ==============================
_COMP_PROP_CACHE = {}
def competitor_propensity_score(comp_seq: str, target_seq: str) -> float:
    """
    Computes the max 7-mer matching score between competitor and target.
    Logic unchanged: max exact character matches over all 7-mer alignments, normalized by 7.
    Vectorized with NumPy for speed.
    """
    if not comp_seq or not target_seq or len(comp_seq) < 7 or len(target_seq) < 7:
        return 0.0

    key = (comp_seq, target_seq)
    if key in _COMP_PROP_CACHE:
        return _COMP_PROP_CACHE[key]

    comp = np.frombuffer(comp_seq.encode('ascii', 'ignore'), dtype=np.uint8)
    targ = np.frombuffer(target_seq.encode('ascii', 'ignore'), dtype=np.uint8)

    best = 0
    for i in range(len(comp) - 6):
        w = comp[i:i+7]
        for j in range(len(targ) - 6):
            matches = np.sum(w == targ[j:j+7])
            if matches > best:
                best = matches
                if best == 7:
                    break
        if best == 7:
            break

    score = float(best) / 7.0
    _COMP_PROP_CACHE[key] = score
    return score

# ==============================
# CHUNKED GENERATOR
# ==============================
def chunked(iterable, n):
    """
    Yield successive lists (chunks) of size n from iterable.
    """
    while True:
        chunk = list(islice(iterable, n))
        if not chunk:
            break
        yield chunk

# ==============================
# ROW BUILDER FOR PARALLELISM (pure function, picklable)
# ==============================

def build_rows_for_combo(args):
    """
    Top-level row builder for multiprocessing.
    Args:
        args: tuple of (
            primary_data: dict,
            target_data: dict,
            competitor_data: dict,
            family_prior_map: dict,
            family_typical_seed_map: dict,
            max_seed_len: int
        )
    Returns:
        list of 1 or 2 row dicts
    """
    (
        primary_data,
        target_data,
        competitor_data,
        family_prior_map,
        family_typical_seed_map,
        max_seed_len
    ) = args

    # Inputs
    mirna_id = primary_data.get('id')
    # Prefer mature_sequence if present, else fallback to full sequence
    mirna_seq = primary_data.get('mature_sequence', primary_data.get('sequence', ''))
    target_seq = target_data.get('sequence', '')
    comp_seq = competitor_data.get('sequence', '')

    # Consistent seed window length
    seed_len = 7

    # Pairwise label components (no-competitor)
    seed_score, seed_pos = seed_match_score(mirna_seq, target_seq)  # returns (score in [0,1], best_pos)
    gc_score = gc_strength_score(mirna_seq, target_seq, seed_pos)
    acc_score = accessibility_score(
        target_data.get('structure_vector', '[]'),
        start_pos=seed_pos,
        length=seed_len
    )

    # Family prior and conservation
    family_key = mirna_id.strip().split(' ')[0]
    fam_prior_raw = family_prior_map.get(mirna_id, 0.0)
    fam_prior = normalize_01(fam_prior_raw, 0.0, 1.0)
    cons_raw = primary_data.get('conservation', 0.0)
    cons_n = normalize_01(cons_raw, 0.0, 1.0)

    # Typical seed similarity: compare 7-mer (positions 2–8) to typical 7-mer
    typical_seed = family_typical_seed_map.get(family_key, '')
    seed_region = mirna_seq[1:1+seed_len]  # 7-mer starting at position 2 (1-based)
    if typical_seed:
        seed_similarity = sum(1 for a, b in zip(seed_region, typical_seed[:seed_len]) if a == b)
        seed_similarity_score = seed_similarity / float(seed_len)
    else:
        seed_similarity_score = 0.0

    # Combine into pairwise label (weights preserved)
    w_seed, w_gc, w_acc, w_prior, w_cons, w_typical = 0.30, 0.15, 0.20, 0.15, 0.10, 0.10
    L_pair_raw = (
        w_seed * seed_score +
        w_gc * gc_score +
        w_acc * acc_score +
        w_prior * fam_prior +
        w_cons * cons_n +
        w_typical * seed_similarity_score
    )
    L_pair = normalize_01(L_pair_raw, 0.0, 1.0)

    # Competitor effect: proportional reduction to avoid collapsing to 0
    beta = 0.5  # tune 0.4–0.6
    comp_prop = competitor_propensity_score(comp_seq, target_seq) if comp_seq else 0.0
    L_with_comp = L_pair * (1.0 - beta * comp_prop)
    L_with_comp = max(0.0, min(1.0, L_with_comp))

    # Baseline (no competitor)
    row_base = {
        'primary_id': mirna_id,
        'primary_sequence': mirna_seq,
        'gc_content': primary_data.get('gc_content'),
        'dg': primary_data.get('dg'),
        'structure_vector': primary_data.get('structure_vector'),
        'adjacency_matrix': primary_data.get('adjacency_matrix'),
        'affinity': L_pair,
        'conservation': cons_n,
        'target_id': target_data.get('id'),
        'target_sequence': target_seq,
        'competitor_id': 'NO_COMPETITOR',
        'competitor_sequence': ''
    }

    rows = [row_base]

    # With competitor
    if comp_seq:
        row_comp = dict(row_base)
        row_comp['competitor_id'] = competitor_data.get('id')
        row_comp['competitor_sequence'] = comp_seq
        row_comp['affinity'] = L_with_comp
        rows.append(row_comp)

    return rows


# --- Predict mature region from precursor sequence ---
def predict_mature_region(seq, window=22):
    best_score = -1
    best_region = seq[:window]  # fallback
    canonical_seeds = {'GAGUGU', 'UAGCUU', 'UGAGGU', 'AGCUUA'}  # example motifs

    for i in range(len(seq) - window + 1):
        candidate = seq[i:i+window]
        gc = candidate.count('G') + candidate.count('C')
        gc_ratio = gc / len(candidate)

        seed = candidate[1:8]

        # Seed quality components
        diversity_score = len(set(seed))  # favors varied seeds
        repeat_penalty = -5 if seed in {'AAAAAAA', 'UUUUUUU', 'GGGGGGG', 'CCCCCCC'} else 0
        canonical_bonus = 5 if seed in canonical_seeds else 0

        seed_score = diversity_score + canonical_bonus + repeat_penalty
        score = seed_score - abs(gc_ratio - 0.45) * 10  # penalize extreme GC

        if score > best_score:
            best_score = score
            best_region = candidate

    return best_region

# ==============================
# MAIN DATASET PREPARATION
# ==============================
def prepare_dataset(config):
    start_time = time.time()

    PROJECT_ROOT = config['project_root']
    DATA_ROOT = os.path.join(PROJECT_ROOT, config['data_folders']['main_dataset_folder'])
    RAW_DATA_ROOT = os.path.join(DATA_ROOT, 'raw_data')
    PREPARED_DATASET_DIR = os.path.join(DATA_ROOT, config['data_folders']['prepared_subfolder'])
    os.makedirs(PREPARED_DATASET_DIR, exist_ok=True)
    PARAMS = {**config.get('processing_parameters', {}), **config.get('training_parameters', {})}

    print("--- Starting Universal Dataset Preparation ---")

    # --------------------------------------------
    # Step 1: Load data sources
    # --------------------------------------------
    print("\nStep 1: Loading all data sources from config...")
    data_sources = {}
    for name, source_info in config['data_sources'].items():
        if name.startswith('_'):
            continue
        path = os.path.join(RAW_DATA_ROOT, source_info['folder'])
        if source_info['type'] == 'fasta':
            data_sources[name] = load_data_from_fasta(path)
        elif source_info['type'] == 'score':
            data_sources[name] = load_scores(path, source_info['id_col'], source_info['score_col'], name.capitalize())
        else:
            print(f"  - Unknown data source type for '{name}': {source_info['type']}")

    run_id_matching_diagnostics(data_sources.get('mirna', {}), data_sources.get('affinity', {}))

    # --------------------------------------------
    # Step 2: Pre-processing all molecule types
    # --------------------------------------------
    print("\nStep 2: Pre-processing all molecule types...")
    processed_data = {}
    exp_setup = config['experiment_setup']

    # Sliding window parameters from config
    sw_params = PARAMS.get('sliding_window', {})
    use_sw = sw_params.get('use_sliding_window', False)
    window_size = sw_params.get('window_size', 500)
    step_size = sw_params.get('step_size', 250)

    for role, molecule_type in exp_setup.items():
        role_key = f"{molecule_type.lower()}_{role.replace('_molecule','')}" if 'molecule' in role else molecule_type.lower()
        if role == 'primary_molecule':
            role_key = molecule_type.lower()

        if role_key not in data_sources or not data_sources[role_key]:
            print(f"  - WARNING: No data found for '{role}' (source key: '{role_key}'). Skipping.")
            processed_data[role] = []
            continue

        print(f"  - Processing {role} ({molecule_type})...")
        raw_molecules = data_sources[role_key]

        # Apply sliding window to target if enabled
        processed_molecules = []
        for mol_id, seq in raw_molecules.items():
            if use_sw and role == 'target_molecule' and len(seq) > window_size:
                num_chunks = 0
                for i in range(0, len(seq) - window_size + 1, step_size):
                    chunk_seq = seq[i:i + window_size]
                    chunk_id = f"{mol_id}_chunk_{i}"
                    processed_molecules.append((chunk_id, chunk_seq))
                    num_chunks += 1
                print(f"    - Sliced target {mol_id} (len {len(seq)}) into {num_chunks} chunks of size {window_size}", end='\r')
            else:
                processed_molecules.append((mol_id, seq))
        if use_sw:
            print()  # newline after slicing messages

        processor_func = PROCESSOR_MAP.get(molecule_type)
        if not processor_func:
            processed_data[role] = []
            continue

        # Prepare args as in your original structure
        with Pool(processes=cpu_count()) as pool:
            processing_args = [((mol_id, seq), PARAMS, role) for (mol_id, seq) in processed_molecules]
            results = list(tqdm(
                pool.imap(processor_func, processing_args),
                total=len(processing_args),
                desc=f"Processing {role}"
            ))

        processed_data[role] = [res for res in results if isinstance(res, dict)]
        print(f"    - {len(processed_data[role])} molecules/chunks passed processing.")

    primary_molecules = processed_data.get('primary_molecule', [])
    target_molecules = processed_data.get('target_molecule', [])
    competitor_molecules = processed_data.get('competitor_molecule', [])

    if not primary_molecules or not target_molecules:
        print("\nCRITICAL ERROR: No primary or target molecules remained after processing. Halting.")
        return

    # --------------------------------------------
    # Step 3: Separating Known vs. Unknown Primary Molecules
    # --------------------------------------------
    print("\nStep 3: Separating Known vs. Unknown Primary Molecules...")
    known_primary_molecules = []
    unknown_primary_molecules = []

    for molecule_data in primary_molecules:
        molecule_id = molecule_data['id']
        if data_sources.get('affinity', {}).get(molecule_id) is not None:
            known_primary_molecules.append(molecule_data)
        else:
            unknown_primary_molecules.append(molecule_data)

    print(f"  - Found {len(known_primary_molecules)} molecules with family prior scores.")
    print(f"  - Found {len(unknown_primary_molecules)} molecules with no prior (will be down-sampled).")

    # Down-sample unknowns to balance compute
    ratio = PARAMS.get('downsampling_ratio_unknown_to_known', 1.0)
    num_known = len(known_primary_molecules)
    num_unknown_to_keep = min(len(unknown_primary_molecules), int(max(1, num_known) * ratio))

    print(f"\nDown-sampling unknowns from {len(unknown_primary_molecules)} to {num_unknown_to_keep} (Known:Unknown Ratio ≈ 1:{ratio})...")
    unknown_subsample = random.sample(unknown_primary_molecules, num_unknown_to_keep) if num_unknown_to_keep > 0 else []

    balanced_primary_molecules = known_primary_molecules + unknown_subsample
    random.shuffle(balanced_primary_molecules)
    print(f"  - Created a balanced primary molecule set of {len(balanced_primary_molecules)} total entries.")

    # --------------------------------------------
    # Step 4: Augmenting datasets with conservation (no random labels)
    # --------------------------------------------
    print("\nStep 4: Augmenting datasets with conservation (no random labels)")
    # Only set conservation on primary molecules; do NOT set 'affinity' here anymore
    for molecule_data in balanced_primary_molecules:
        molecule_id = molecule_data['id']
        # Conservative family mapping: try to extract family-like key
        mirna_family_match = re.search(r"hsa-mir-\d+[a-z]?", molecule_id.lower())
        mirna_family_name = mirna_family_match.group(0) if mirna_family_match else molecule_id.lower()
        molecule_data['conservation'] = data_sources.get('conservation', {}).get(mirna_family_name, 0.0)
    print("  - Augmentation complete.")

    # --------------------------------------------
    # Step 5: Preparing Final Competitor List
    # --------------------------------------------
    print("\nStep 5: Preparing Final Competitor List...")
    null_competitor = {
        'id': 'NO_COMPETITOR', 'sequence': '', 'original_sequence': '',
        'gc_content': 0.0, 'dg': 0.0, 'structure_vector': '[]', 'adjacency_matrix': '[]'
    }
    competitors_augmented = competitor_molecules + [null_competitor]
    print(f"  - Final competitor list contains {len(competitors_augmented)} entries (including null).")

    # =========================================================================================
    # STEP 6: GENERATING AND SHUFFLING COMBINATIONS (RAM-safe, chunked)
    # =========================================================================================
    print("\nStep 6: Generating and Shuffling Combinations with Progress...")
    total_combinations_count = (
        len(balanced_primary_molecules)
        * len(target_molecules)
        * len(competitors_augmented)
    )
    print(f"  - Preparing to generate {total_combinations_count:,} combinations...")

    from itertools import islice

    def chunked(iterable, n):
        while True:
            chunk = list(islice(iterable, n))
            if not chunk:
                break
            yield chunk

    dp = config.get('data_processing', {})
    PARQUET_BATCH_SIZE = int(dp.get('batch_size_parquet', 1_000_000))  # larger default, unified
    CHUNK_SIZE = max(20_000, PARQUET_BATCH_SIZE)  # block-level shuffle
    PARQUET_COMPRESSION = dp.get('parquet_compression', 'snappy')
    PARQUET_PREFIX = dp.get('parquet_output_prefix', 'training_combinations')

    output_folder = PREPARED_DATASET_DIR
    os.makedirs(output_folder, exist_ok=True)
    output_base = os.path.join(output_folder, PARQUET_PREFIX)

    # Initialize parquet streaming state ONCE (no redefinitions later)
    buffer = []
    part_idx = 0
    total_rows_written = 0
    parquet_schema = None

    def flush_parquet_buffer():
        nonlocal buffer, part_idx, total_rows_written, parquet_schema
        if not buffer:
            return
        table = pa.Table.from_pylist(buffer, schema=parquet_schema)
        if parquet_schema is None:
            parquet_schema = table.schema
            table = table.cast(parquet_schema)
        else:
            table = table.cast(parquet_schema)
        part_path = f"{output_base}_part{part_idx:05d}.parquet"
        pq.write_table(table, part_path, compression=PARQUET_COMPRESSION)
        total_rows_written += len(buffer)
        buffer.clear()
        part_idx += 1

    # Use a generator — do not materialize
    combination_generator = product(balanced_primary_molecules, target_molecules, competitors_augmented)
    
    # --- Auto-generate family_typical_seed_map from available miRNAs ---
    from collections import Counter, defaultdict

    family_seed_counts = defaultdict(Counter)

    # Collect seeds for each family from all primary molecules
    for mol in balanced_primary_molecules:
        full_seq = mol.get('sequence', '')
        mol['mature_sequence'] = predict_mature_region(full_seq)
        mirna_id = mol.get('id', '')
        mirna_seq = mol.get('sequence', '')
        if not mirna_seq:
            continue
        family_key = mirna_id.strip().split(' ')[0]  # adjust if your family naming differs
        seed = mirna_seq[:7]
        family_seed_counts[family_key][seed] += 1

    # Pick the most common seed for each family
    family_typical_seed_map = {
        fam: counts.most_common(1)[0][0]
        for fam, counts in family_seed_counts.items()
    }

    print(f"  - Auto-generated typical seeds for {len(family_typical_seed_map)} families")

    family_prior_map = data_sources.get('affinity', {})
    
    # =========================================================================================
    # STEP 7: PRESELECTED SAMPLING (unbiased ~200k rows), memory-safe shuffle & write
    # =========================================================================================
    print("\nStep 7: Preselecting combinations for ~200k rows (unbiased), then building & writing...")
    start_write_time = time.time()

    # --- Diagnostics & parameters ---
    P = len(balanced_primary_molecules)
    T = len(target_molecules)
    C_plus_1 = len(competitors_augmented)  # includes explicit NULL competitor
    C_real = max(0, C_plus_1 - 1)          # real competitors (with non-empty sequences)

    N_combos = P * T * C_plus_1             # total combinations (generator size)
    print(f"  - P (miRNAs): {P:,}, T (targets): {T:,}, (C+1) competitors (incl. null): {C_plus_1:,}")
    print(f"  - Total combinations (P*T*(C+1)): {N_combos:,}")

    # Expected rows per combination with current builder:
    #   Null competitor combo -> 1 row
    #   Real competitor combo -> 2 rows (baseline + with-competitor)
    #   Prob(null) = 1/(C+1), Prob(real) = C/(C+1)
    #   E[rows/combo] = (1 * 1/(C+1)) + (2 * C/(C+1)) = (1 + 2C)/(C+1)
    expected_rows_per_combo = (1 + 2 * C_real) / float(C_plus_1)

    # --- Config knobs ---
    dp = config.get('data_processing', {})
    TARGET_ROWS = int(dp.get('target_rows', 200_000))  # your requested target
    SHUFFLE_BUFFER_ROWS = int(dp.get('shuffle_buffer_rows', 1_000_000))
    FLUSH_PORTION = float(dp.get('shuffle_flush_portion', 0.5))
    assert 0 < FLUSH_PORTION <= 1.0, "shuffle_flush_portion must be in (0, 1]"

    # Compute number of combinations to preselect to hit ~TARGET_ROWS in expectation
    K = max(1, int(round(TARGET_ROWS / expected_rows_per_combo)))
    K = min(K, N_combos)  # guard
    print(f"  - Target rows: {TARGET_ROWS:,}")
    print(f"  - Expected rows/combination: {expected_rows_per_combo:.5f}")
    print(f"  - Preselecting K combinations: {K:,} (unbiased)")

    # --- Preselect K unique flat indices uniformly from [0, N_combos)
    # Reproducible because random.seed(42) is set at top of script
    selected_indices = set(random.sample(range(N_combos), K))

    # --- Helper to map flat index -> (p_idx, t_idx, c_idx)
    def index_to_ptc(idx, P, T, C1):
        c_idx = idx % C1
        tmp = idx // C1
        t_idx = tmp % T
        p_idx = tmp // T
        return p_idx, t_idx, c_idx

    # --- Prepare progress bar over K selected combinations
    from tqdm import tqdm as tqdm_progress

    pbar = tqdm_progress(total=K, desc="  Building selected combos")

    # --- Rolling shuffle writer state (reuse your previously-initialized vars if present) ---
    # buffer, parquet_schema, part_idx, total_rows_written, output_base, PARQUET_COMPRESSION must exist
    def flush_some_rows_portion(portion=FLUSH_PORTION):
        nonlocal buffer, parquet_schema, part_idx, total_rows_written
        if not buffer:
            return
        random.shuffle(buffer)
        n_write = max(1, int(len(buffer) * portion))
        to_write = buffer[:n_write]
        buffer = buffer[n_write:]

        table = pa.Table.from_pylist(to_write, schema=parquet_schema)
        if parquet_schema is None:
            parquet_schema = table.schema
            table = table.cast(parquet_schema)
        else:
            table = table.cast(parquet_schema)

        part_path = f"{output_base}_part{part_idx:05d}.parquet"
        pq.write_table(table, part_path, compression=PARQUET_COMPRESSION)
        total_rows_written += len(to_write)
        part_idx += 1

    # Build only the preselected combinations, in parallel, memory-safe and Create an iterator over the selected p,t,c triples without materializing them all at once
    
    def selected_args_iter():
        # Iterate in any order; mixing is handled by buffer shuffle
        for idx in selected_indices:
            p_idx, t_idx, c_idx = index_to_ptc(idx, P, T, C_plus_1)
            p = balanced_primary_molecules[p_idx]
            t = target_molecules[t_idx]
            c = competitors_augmented[c_idx]
            yield (p, t, c, family_prior_map, family_typical_seed_map, 30)

    # Use a single Pool for throughput
    DEBUG_NO_MP = False  # set True to debug serially, False for full-speed multiprocessing

    if DEBUG_NO_MP:
        # Serial path: easy to see exceptions, slower
        for args in selected_args_iter():
            rows = build_rows_for_combo(args)
            buffer.extend(rows)
            if len(buffer) >= SHUFFLE_BUFFER_ROWS:
                flush_some_rows_portion(FLUSH_PORTION)
            pbar.update(1)
    else:
        # Parallel path: fast
        with Pool(processes=max(1, cpu_count() - 1)) as pool:
            for rows in pool.imap_unordered(build_rows_for_combo, selected_args_iter(), chunksize=1000):
                buffer.extend(rows)
                if len(buffer) >= SHUFFLE_BUFFER_ROWS:
                    flush_some_rows_portion(FLUSH_PORTION)
                pbar.update(1)

    # Final flush of whatever remains
    flush_some_rows_portion(portion=1.0)
    pbar.close()

    end_write_time = time.time()
    print(f"\n  - Wrote {total_rows_written:,} rows across {part_idx} Parquet part files (prefix: {os.path.basename(output_base)}).")
    print(f"  - Time taken for this step: {end_write_time - start_write_time:.2f} seconds")
    print(f"  - Notes: Preselected K={K:,} combos from N={N_combos:,}; expected rows/combo={expected_rows_per_combo:.5f}")

# ==============================
# ENTRY POINT
# ==============================
if __name__ == "__main__":
    config = load_config()
    prepare_dataset(config)
